from database.database import get_db


async def add_channel(chat_id: str, username: str | None, title: str | None,
                       channel_type: str = "mandatory") -> bool:
    db = await get_db()
    try:
        try:
            await db.execute(
                "INSERT INTO channels (chat_id, username, title, channel_type) VALUES (?, ?, ?, ?)",
                (chat_id, username, title, channel_type),
            )
            await db.commit()
            return True
        except Exception:
            return False
    finally:
        await db.close()


async def remove_channel(channel_id: int):
    db = await get_db()
    try:
        await db.execute("DELETE FROM channels WHERE id = ?", (channel_id,))
        await db.commit()
    finally:
        await db.close()


async def get_mandatory_channels():
    db = await get_db()
    try:
        cur = await db.execute(
            "SELECT id, chat_id, username, title FROM channels WHERE channel_type='mandatory' AND is_active=1"
        )
        rows = await cur.fetchall()
        return [{"id": r[0], "chat_id": r[1], "username": r[2], "title": r[3]} for r in rows]
    finally:
        await db.close()


async def get_all_channels():
    db = await get_db()
    try:
        cur = await db.execute("SELECT id, chat_id, username, title, channel_type FROM channels")
        rows = await cur.fetchall()
        return [
            {"id": r[0], "chat_id": r[1], "username": r[2], "title": r[3], "channel_type": r[4]}
            for r in rows
        ]
    finally:
        await db.close()
