from database.database import get_db


async def add_film(film_code: str, title: str, file_id: str, poster_file_id: str | None = None,
                    genre: str | None = None, language: str | None = None, year: str | None = None,
                    description: str | None = None, is_series: bool = False) -> bool:
    db = await get_db()
    try:
        try:
            await db.execute(
                """INSERT INTO films (film_code, title, file_id, poster_file_id, genre, language,
                   year, description, is_series) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (film_code, title, file_id, poster_file_id, genre, language, year, description,
                 int(is_series)),
            )
            await db.commit()
            return True
        except Exception:
            return False
    finally:
        await db.close()


async def get_film_by_code(film_code: str):
    db = await get_db()
    try:
        cur = await db.execute("SELECT * FROM films WHERE film_code = ?", (film_code,))
        row = await cur.fetchone()
        if row is None:
            return None
        cols = [d[0] for d in cur.description]
        return dict(zip(cols, row))
    finally:
        await db.close()


async def increment_views(film_code: str):
    db = await get_db()
    try:
        await db.execute("UPDATE films SET views = views + 1 WHERE film_code = ?", (film_code,))
        await db.commit()
    finally:
        await db.close()


async def update_film_field(film_code: str, field: str, value):
    allowed = {"title", "file_id", "poster_file_id", "description", "film_code", "genre",
               "language", "year"}
    if field not in allowed:
        raise ValueError("Bunday maydonni tahrirlab bo'lmaydi")
    db = await get_db()
    try:
        await db.execute(f"UPDATE films SET {field} = ? WHERE film_code = ?", (value, film_code))
        await db.commit()
    finally:
        await db.close()


async def delete_film(film_code: str):
    db = await get_db()
    try:
        await db.execute("DELETE FROM films WHERE film_code = ?", (film_code,))
        await db.commit()
    finally:
        await db.close()


async def add_episode(film_id: int, episode_number: int, file_id: str) -> bool:
    db = await get_db()
    try:
        try:
            await db.execute(
                "INSERT INTO episodes (film_id, episode_number, file_id) VALUES (?, ?, ?)",
                (film_id, episode_number, file_id),
            )
            await db.execute("UPDATE films SET is_series = 1 WHERE id = ?", (film_id,))
            await db.commit()
            return True
        except Exception:
            return False
    finally:
        await db.close()


async def get_episodes(film_id: int):
    db = await get_db()
    try:
        cur = await db.execute(
            "SELECT episode_number, file_id FROM episodes WHERE film_id = ? ORDER BY episode_number",
            (film_id,),
        )
        rows = await cur.fetchall()
        return [{"episode_number": r[0], "file_id": r[1]} for r in rows]
    finally:
        await db.close()


async def get_top_films(limit: int = 10):
    db = await get_db()
    try:
        cur = await db.execute(
            "SELECT film_code, title, views FROM films ORDER BY views DESC LIMIT ?", (limit,)
        )
        rows = await cur.fetchall()
        return [{"film_code": r[0], "title": r[1], "views": r[2]} for r in rows]
    finally:
        await db.close()
